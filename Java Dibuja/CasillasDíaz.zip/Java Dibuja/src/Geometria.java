import java.awt.*;

public abstract class Geometria {

    abstract public void dibujar(Graphics g);
}
